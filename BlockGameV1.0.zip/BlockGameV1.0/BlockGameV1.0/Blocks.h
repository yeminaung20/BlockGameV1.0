#include<stdio.h>

struct Block
{
	char shape[5];
	int indexX[5];
	int indexY[5];
	int total;
	int loc[10];
	int locLen;
};
Block LINE();
Block Blocks(int whichBlock)
{
	switch(whichBlock)
	{
	case 1:return LINE();break;
	}

}
Block LINE()
{
	Block LINE;
	int d;
	for(d=0;d<3;d++)
	{
		LINE.shape[d] = 219;
	}
	LINE.indexX[0] = 4;
	LINE.indexX[1] = 4;
	LINE.indexX[2] = 4;

	LINE.indexY[0] = 0;
	LINE.indexY[1] = 1;
	LINE.indexY[2] = 2;

	LINE.total = 3;

	LINE.loc[0] = 4;
	LINE.loc[1] = 0;
	LINE.loc[2] = 4;
	LINE.loc[3] = 1;
	LINE.loc[4] = 4;
	LINE.loc[5] = 2;

	LINE.locLen=6;
	return LINE;
}