#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<process.h>

#include "Blocks.h"

#define LEFT 'a'
#define RIGHT 'd'
#define UP 'w'
#define DOWN 's'
#define EXIT 'h'
#define BLANK 176
#define Bl 219

void main(){
	

	char StandardMap[10][10];
	
	int i;

	int remainder;
	int result;
	int result2=0;

	for(i=0;i<100;i++){
	result = (i+1)/10;
	remainder = i%10;
	StandardMap[remainder][result]=176;
	}

	system("cls");
	Block GET;
	GET = Blocks(1);
	for(i=0;i<GET.total ;i++)
	{
		StandardMap[GET.indexX[i]][GET.indexY[i]] = GET.shape[i];
	}
	printf("############\n#");
	for(i=0;i<100;i++){
	result = (i+1)/10;
	remainder = i%10;
	printf("%c",StandardMap[remainder][result]);

	if(result!= result2){
	  printf("#\n#");
	}

	result2=result;
	}
	printf("###########\n");
	int flag=0;
	char scan;
	while(1)
	{
		result2 =0;
		flag = 0;

	scanf("%c",&scan);
	if(scan == LEFT){
		StandardMap[GET.loc[0]-1][GET.loc[1]] = Bl;
		StandardMap[GET.loc[2]-1][GET.loc[3]] = Bl;
		StandardMap[GET.loc[4]-1][GET.loc[5]] = Bl;

		StandardMap[GET.loc[0]][GET.loc[1]] = BLANK;
		StandardMap[GET.loc[2]][GET.loc[3]] = BLANK;
		StandardMap[GET.loc[4]][GET.loc[5]] = BLANK;

		GET.loc[0] = GET.loc[0]-1;
		GET.loc[2] = GET.loc[2]-1;
		GET.loc[4] = GET.loc[4]-1;
		flag =1;
	}
	if(scan == RIGHT){
		StandardMap[GET.loc[0]+1][GET.loc[1]] = Bl;
		StandardMap[GET.loc[2]+1][GET.loc[3]] = Bl;
		StandardMap[GET.loc[4]+1][GET.loc[5]] = Bl;

		StandardMap[GET.loc[0]][GET.loc[1]] = BLANK;
		StandardMap[GET.loc[2]][GET.loc[3]] = BLANK;
		StandardMap[GET.loc[4]][GET.loc[5]] = BLANK;

		GET.loc[0] = GET.loc[0]+1;
		GET.loc[2] = GET.loc[2]+1;
		GET.loc[4] = GET.loc[4]+1;
		flag =1;
	}
	if(scan == DOWN){
		StandardMap[GET.loc[4]][GET.loc[5]+1] = Bl;
		StandardMap[GET.loc[4]][GET.loc[5]] = BLANK;
		StandardMap[GET.loc[2]][GET.loc[3]+1] = Bl;
		StandardMap[GET.loc[2]][GET.loc[3]] = BLANK;
		StandardMap[GET.loc[0]][GET.loc[1]+1] = Bl;
		StandardMap[GET.loc[0]][GET.loc[1]] = BLANK;

		GET.loc[1] = GET.loc[1]+1;
		GET.loc[3] = GET.loc[3]+1;
		GET.loc[5] = GET.loc[5]+1;
		flag =1;
	}
	if(scan == UP){
		StandardMap[GET.loc[0]][GET.loc[1]-1] = Bl;
		StandardMap[GET.loc[0]][GET.loc[1]] = BLANK;
		StandardMap[GET.loc[2]][GET.loc[3]-1] = Bl;
		StandardMap[GET.loc[2]][GET.loc[3]] = BLANK;
		StandardMap[GET.loc[4]][GET.loc[5]-1] = Bl;
		StandardMap[GET.loc[4]][GET.loc[5]] = BLANK;

		GET.loc[1] = GET.loc[1]-1;
		GET.loc[3] = GET.loc[3]-1;
		GET.loc[5] = GET.loc[5]-1;
		flag =1;
	}
	if(flag==1&&scan!= EXIT){
		printf("############\n#");
	for(i=0;i<100;i++){
	result = (i+1)/10;
	remainder = i%10;
	printf("%c",StandardMap[remainder][result]);

	if(result!= result2){
		
		printf("#\n#");
	}

	result2=result;
	}
		printf("###########\n");
	}
	}
}
